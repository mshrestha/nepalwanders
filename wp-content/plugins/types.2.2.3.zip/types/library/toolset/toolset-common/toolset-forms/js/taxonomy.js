jQuery(document).ready(function () {
    initTaxonomies(wptoolset_taxonomy_settings.values, wptoolset_taxonomy_settings.name, wptoolset_taxonomy_settings.form, wptoolset_taxonomy_settings.field);
});